// 07 - crie uma função que retorne o triplo do número recebido no parâmetro da função
// 08 - crie uma função que  verifique se uma  variável é true ou false
// 09 - Crie um array que receba 5 itens e exiba no console.
// 10 - Utilize um método para adicionar um nome ao inicio do array.
// 11 - Utilize um método para remover o último nome do array.
// 12 - Utilize um método para adicionar dois nomes ao fim do array.
// 13 - Utilize um método para remover o primeiro nome do array.
// 14 - Utilize um método para adicionar no meio deste array.
// let nome = ["João",  "Maria",  "Jose",  "Pedro"]
// 15 - Utilize um método para organizar em ordem crescente o seguinte array:
// let numbers = [7,5,6,3,8,9,2,1,4]

let dia = "amanheceu";

if (dia=="amanheceu") {
console.log ("Bom dia! Está claro.")
}

else {
console.log ("Boa noite! Agora está de noite.")
}

let n=2;

for (let n=2; n <=20; n+=2) { console.log (n) }

// function mensagem = o nome da função a ser ativa
// (frase) = parâmetro definido para essa função

function mensagem (frase) {
console.log (frase)
}
mensagem ("Essa é uma mensagem exibida apenas no console.");

function nome (meuNome) {
console.log (`Meu nome é `+meuNome)
}
nome ("Elias");

function sobreMim (Nome, Idade, estiloMusical) {
    console.log (`Meu nome é `+Nome+`. `)
    console.log (`Minha idade é `+Idade+`. `)
    console.log (`E o meu estilo musical favorito é `+estiloMusical+`.`)
    }
    sobreMim ("Elias Augusto", "26", "Indie");

function favoritos (Filme, Musica) {
    console.log (`Meu filme favorito é `+Filme+`. `)
    console.log (`Minha música favorita é `+Musica+`. `)
    }
    favoritos ('"A Chegada"', '"November - Max Ritcher"');



